#include<iostream>
#include<string>
#include "infrastructure.h"

using namespace std;
//using namespace searching_tools;
using namespace working_with_file;
namespace phase2{
	void show_stop_words()
	{
		indexing::normalize n("salam is one of best words in world");
	}
}
namespace phase1
{
	void count()
	{
		data_to_work d;
		
		cout<<"Please enter the statement that you want to find:"<<endl;
		string statement;
		ws(cin);
		getline(cin, statement);
		
			
		cout<<"Processing..."<<endl;
		
		
		
		searching_tools::search_work search_doer;
		search_doer.input_data = &d.files;
		search_doer.statement_list.push_back(statement);
		search_doer.do_it();
		search_doer.cal_for_each_file();
		cout<<endl<<"Count of this statement usage in default files is: "<<search_doer.result_list.size()<<endl;
		
	}
	void replace()
	{
		//data_to_work d;
		cout<<"Please enter full file path:"<<endl;
		
		string file_path;// = "E:/New Projects/SharifSearch/Data/Source/23/60912";
		ws(cin);
		getline(cin, file_path);
		
		
		cout<<endl<<"Please enter the statement that you want to find:"<<endl;
		string statement;
		ws(cin);
		getline(cin, statement);
		cout<<endl<<"Please enter a term to replace with:"<<endl;
		
		string to;
		ws(cin);
		getline(cin, to);
		
		cout<<endl<<"Processing..."<<endl;
		
		
		vector<file> files;
		file the_only_file(file_path,id_maker());
		the_only_file.StartWork();
		//cout<<endl<<"Size of file:"<<the_only_file.size<<endl;
		files.push_back(the_only_file);
		
		searching_tools::search_work search_doer;
		search_doer.input_data = &files;
		search_doer.statement_list.push_back(statement);
		search_doer.do_it();
		if (search_doer.result_list.size() > 0)
			cout<<"Found "<<search_doer.result_list.size()<<" cases. Now replacing..."<<endl;
		else
			cout<<"No items found"<<endl;
		
		searching_tools::replace_work replace_doer(statement, to);
		replace_doer.do_replace(&files, search_doer);
		cout<<"Replacing completed.";
	}
	
	void report_index()
	{
		data_to_work d;
		
		cout<<"Please enter the statement that you want to find:"<<endl;
		string statement;
		
		ws(cin);
		getline(cin, statement);
		
			
		cout<<"Processing..."<<endl;
		
		
		
		searching_tools::search_work search_doer;
		search_doer.statement_list.push_back(statement);
		
		search_doer.input_data = &(d.files);
		search_doer.do_it();
		
		search_doer.print_results();
	}
}
